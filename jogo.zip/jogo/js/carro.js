//posições dos carros
/*let xCarros1 = 600;

let xCarros2 = 600;

let xCarros3 = 600;*/

let xCarros = [700, 700, 700, 700, 700, 700]

let yCarros = [50, 120, 185, 260, 330, 400]

let velocidadeCarros = [2,9,6,5,5,8]

let comprimentoCarros = 70;
let alturaCarros = 50;

function mostrarCarros(){

    for (let i=0; i < imagensCarros.length; i++) {

    image (imagensCarros[i], xCarros[i], yCarros[i], comprimentoCarros, alturaCarros); 
        
    }

/*image(imagemCarro01, xCarros1, 40, comprimentoCarros, alturaCarros);
image(imagemCarro02, xCarros2, 95, 60, 40);
image(imagemCarro03, xCarros3, 150, 60, 40);*/

}

function movimentoCarro() {

    for (let i = 0; i < imagensCarros.length; i++) {

        xCarros[i] -= velocidadeCarros[i];

        if(xCarros[i] < -comprimentoCarros) {
            xCarros [i] = width;
        }
}

}