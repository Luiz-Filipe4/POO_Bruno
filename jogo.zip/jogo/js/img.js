let imagemDaEstrada;
let imagemCarro01;
let imagemCarro02;
let imagemCarro03;
let imagemMascote;
let imagensCarros;


function preload () {

imagemDaEstrada = loadImage("img/estrada.png");
imagemMascote = loadImage("img/mascote.png");
imagemCarro01 = loadImage("img/carro-1.png");
imagemCarro02 = loadImage("img/carro-2.png");
imagemCarro03 = loadImage("img/carro-3.png");

imagensCarros= [imagemCarro01, imagemCarro02, imagemCarro03,
    imagemCarro01, imagemCarro02, imagemCarro03];
}


