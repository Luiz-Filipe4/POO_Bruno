let yMascote = 460;
let xMascote = 375;
let meusPontos = 0;

let colisao = false;

function verificaColisao () {
    for (let i = 0; i < imagensCarros.length; i++) {

        colisao = collideRectCircle(xCarros[i], yCarros[i], comprimentoCarros, alturaCarros, xMascote, yMascote, 30)
        if (colisao) {
            voltaPontos();
            if (meusPontos > 0) {
            meusPontos -= 1;
        }

        }
    }    

    print('Colisao Acontecendo', colisao)
}

function voltaPontos() {
    yMascote = 460;
    xMascote = 375;
}

function mostrarMascote() {
    image (imagemMascote, xMascote, yMascote, 40, 40);
}

function incluirPontos() {

text(meusPontos, 20, 25)
fill(color(255,0,0))
textSize(21)
}

function pontuar() {
    if (yMascote < 1) {
        yMascote = 460
        xMascote = 375
        meusPontos ++
    }
    
}
function movimentoMascote() {

    if (keyIsDown(UP_ARROW)) {
        
        yMascote -=6;

    }

    if (keyIsDown(DOWN_ARROW)) {
        
        yMascote +=6;

    }

    if (keyIsDown(RIGHT_ARROW)) {
        
        xMascote +=6;

    }

    if (keyIsDown(LEFT_ARROW)) {
        
        xMascote -=6;

    }


    


}