
//na função setup definimos as configurações de largura e altura
function setup() {
    
    createCanvas(750, 500);

}


//na função de desenho definimos o que será exibido
function draw() {

background(imagemDaEstrada);

//O image permite manipular o objeto no eixo X e Y como também W e H

mostrarMascote();
mostrarCarros();
movimentoCarro();
movimentoMascote();
incluirPontos();
verificaColisao();
pontuar()
}