package br.com.music.app;
import br.com.music.model.Audio;

public class Main {

	public static void main(String[] args) {
		
		Audio audios = new Audio();
		
		Audio.Reproduzir();
		
	}

}
